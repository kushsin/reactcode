
//import React, { useState } from "react";
import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

//
//import Todolist from "./Todolist";
//port Project from "./Project";
// <Thetime></Thetime>
/*//<Project/>,
  //<MYform/>
  <Project/>,
  //
  */

  ReactDOM.render(
    <App></App>,
    document.getElementById('root')
  );
    





 
  


