import react from "react";
 const Sdata = [

    {
        sname : "DARK",
        imgsrc : "https://i0.wp.com/www.secondhalftravels.com/wp-content/uploads/2018/08/Dark-German-series-Netflix.jpg?resize=780%2C400&ssl=1",
        title :"Netflix Original Series",
        link :"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.secondhalftravels.com%2Fgerman-tv-shows-netflix%2F&psig=AOvVaw2DX46Rwa9a_h-NFsQwHkKf&ust=1641647483019000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCNDKoNLbn_UCFQAAAAAdAAAAABAD"
               
    },
    {
        sname : "SABRINA",
        imgsrc : "https://static0.srcdn.com/wordpress/wp-content/uploads/2020/02/Netflix-Original-Series.jpg",
        title :"Netflix Original Series",
        link :"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.cnet.com%2Fnews%2Fnetflix-chilling-adventures-of-sabrina-conjures-chaos-in-the-new-trailer%2F&psig=AOvVaw1uy_7JZzoWtYieRa25s0PP&ust=1641647595354000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCKjOlYXcn_UCFQAAAAAdAAAAABAD"
          },

    {
        sname : "Brooklyn Nine-NINE",
        imgsrc : "https://cdn.wealthygorilla.com/wp-content/uploads/2019/04/Best-Netflix-TV-Series-Brooklyn-Nine-Nine-800x450.jpg",
        title :"Netflix Original Series",
        link :"https://www.google.com/url?sa=i&url=https%3A%2F%2Fbrooklyn99.fandom.com%2Fwiki%2FSeason_Five&psig=AOvVaw0k9Grjh6QzhWh8ozwkeJDO&ust=1641647666221000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCNCz9qfcn_UCFQAAAAAdAAAAABAE"
              
    },
    {
        sname : "The Girl From Oslo",
        imgsrc : "https://www.algemeiner.com/wp-content/uploads/2021/12/oslo.jpg",
        title : "Netflix Original Series",
        link:"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D-jnVn4YCaR0&psig=AOvVaw3uhNb8opBJrak8jo-QTxI3&ust=1641647780880000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCJjSy9ncn_UCFQAAAAAdAAAAABAD"
        
    },
    {
        sname : "ARROW",
        imgsrc : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmFzQFAUn9HvPCTt2TV05E8ZIG35FOL3ZCBw&usqp=CAU",
        title:"Netflix Original Series",
        link: "https://www.google.com/url?sa=i&url=https%3A%2F%2Farrow.fandom.com%2Fwiki%2FSeason_2_(Arrow)&psig=AOvVaw0WzWXGWJZjE1_P9Wi-86lI&ust=1641647839027000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCLC19ffcn_UCFQAAAAAdAAAAABAD"
               
    },
    {
        sname : "Stranger Things",
        imgsrc: "https://media.gettyimages.com/photos/man-wearing-a-mask-walks-past-an-advertising-billboard-of-the-netflix-picture-id1230314322?s=612x612",
        title : "Netflix Original Series",
        link:"https://www.google.com/url?sa=i&url=https%3A%2F%2Fscreenrant.com%2Fbest-original-netflix-shows-sci-fi-fantasy%2F&psig=AOvVaw2BCWbpNmIutYhFuXCAqSEj&ust=1641571875453000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCKDenfvBnfUCFQAAAAAdAAAAABAD"
        
               
    }
 ]
 export default Sdata;